Connectivity fractions
Row format
connection type, cell, connectivity fraction
