See https://github.com/cabrittin/volumetric_analysis for analysis code

Files JSH_maxpostion.csv and N2U_maxposition.csv contain the maximum anterior and posterior position for the L4 and adult datasets, respectively.
These files can be genereated with script scripts/writeContinMaxPositions.py.

Row format for these files is:
cell name, nerve ring cell class, contin number, max anterior section number, max posterior section number.

Contin number refers to a reconstrunction id in the synaptic connectivity (Elegance) database.
A contin is a segment of the reconstruction.
A cell may conist of multiple contins.

If -1 is given for the anterior or posterior position, then it indicates that the specific contin is now deprecated.

Note that in the adult but not the L4, dendrites of Sp1 and Sp2 sensory cells were reconstructed.
The n2u_sp_contins.txt file lists the contins used for the adult analysis.
The row format is

cell name, contin to be used in analysis

The file manually specifies the axon contin of the Sp cells, so that the dendrites are excluded from the analysis.

Note that for the adult analysis the following  line was manually added to N2U_maxposition.csv because of incorrect contin information in the Elegance database:

AVM,Sp1,-999,151,200

Note that the anterior and posterior position are give as section numbers and have not yet been scaled to physical units.

This can be done with the scripts/max_position.py

