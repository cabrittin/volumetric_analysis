discrepant_connections_*_chem.csv : chemical synaptic connections found on the left/right but not on the right/left side
discrepant_connections_*_gap.csv : gap junction synaptic connections found on the left/right side but not on the right/left side
discrepant_connections_*_adj.csv : physical adjacenct connections on the left/right side but not on the right/left side

Row format
cell1, cell2, weight of connection
