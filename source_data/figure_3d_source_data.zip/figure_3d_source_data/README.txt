*_homologous* files contain the jaccard distances between the neighborhoods of homologous cells
Row format
[cell1, cell2, jaccard distance between neighborhoods]

*_overlap* files contain the minimum between jaccard distance of a cell neighborhood and overlapping neighborhoods.
Row format
[cell, jaccard distance]
