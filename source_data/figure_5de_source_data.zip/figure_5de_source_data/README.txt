adjacency_connections_adult.csv  adjacency_connections_l4.csv  expected_vs_actual_synaptic_connections_adult.csv  expected_vs_actual_synaptic_connections_l4.csv

adjacency_connections_*.csv : Shows if an adjacency connection results in a chemical synaptic connection
Row format:
cell1, cell2, amount of contact, 1/0 (1 if it does have a synaptic connection, 0 otherwise)

expected_vs_actual_synaptic_connections_*.csv : Shows the actual and expected number of synaptic connections for each cell based on a model where synaptic connections are determined by the amount of contact between cells.
Row format
cell, number of neighboring cells, actual number of synaptic connections, expected number of synaptic connections, expected variance in the model
