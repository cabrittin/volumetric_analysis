Files:

color_code.txt : color codes used in plot
nerve_ring_classes.txt : cell assigned classes
left_nodes.txt : list of left side cells
right_nodes.txt : list of right side cells.txt

The following files contain the spatial coordinates of presynaptic, postsynaptic and gap junction synapses:

adult_spatial_map_gap.csv
adult_spatial_map_post.csv
adult_spatial_map_pre.csv
l4_spatial_map_gap.csv
l4_spatial_map_post.csv
l4_spatial_map_pre.csv

Row formats:
cell name, radius coordinate, azimuth angle coordinate, z (anterior-posterior) coordinate
