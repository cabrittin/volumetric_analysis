Degree differences between homologous cells
Row format
[cell1, cell2, degree of cell1, degree of cell2, absolute value of (degree cell1 - degree cell2)
