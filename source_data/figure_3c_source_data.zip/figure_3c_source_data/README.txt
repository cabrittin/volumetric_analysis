Difference in log of surface area contacts
Row format
contact pairs, log of contact for cell pair, log of contact for contralateral cell pair, absolute difference of log of contacts
