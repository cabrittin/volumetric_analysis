Adjacency degree data
Row format:
cell name, cell class, adjacency degree
