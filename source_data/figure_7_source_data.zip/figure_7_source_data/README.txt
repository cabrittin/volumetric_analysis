File Edit Options Buffers Tools Text Help
Synopsis of data files

* Contain supplementary data files for Figure 7
  - cam_expression_matrix_N2U.csv -> CAM expression matrix for the adult
  - cam_expression_matrix_JSH.csv -> CAM expression matrix for the l4
  - cam_expression_matrix_N2U_identical.csv -> Lists cells with identical CAM express for the adult.
  - cam_expression_matrix_JSH_identical.csv -> Lists cells with	identical CAM express for the l4.
                Row format: [expression patterns, cell1, cell2, ....] where all cells have the specified expression pattern
  - exp_cluster.gml -> Graph file for expression clusters under the Whole-cell Binary Expression model (WBE)
  - exp_clusters_iso.gml -> Graph file for expression clusters under the Isoform Expression model (IE)
  - N2U_wbe.csv -> Adult LUS scores for the WBE model. Row format: cell name, presynaptic LUS, gap junction LUS
  - N2U_sbe.csv -> Adult LUS scores for the subcell-binary expression model (SBE).
                   Row format: cell name,presynaptic LUS, gap junction LUS
  - N2U_ie.csv ->  Adult LUS scores for 1000 iterations of IE model. LUS scores are the average across all cells.
                   Row format: average presynaptic LUS score, average gap_junction LUS score.
  - JSH_wbe.csv -> L4 LUS scores for the WBE model. Row format: cell name,   presynaptic LUS, gap junction LUS
  - JSH_sbe.csv -> L4 LUS scores for the subcell-binary expression model (SBE).
                   Row format: cell name,presynaptic LUS, gap junction LUS
  - JSH_ie.csv ->  L4 LUS scores for 1000 iterations of IE model. LUS scores are the average across all cells.
		   Row format: average presynaptic LUS score, average gap_junction LUS score.
															   
															       
