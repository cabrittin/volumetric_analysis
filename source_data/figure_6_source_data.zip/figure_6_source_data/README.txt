Files specificity_probability_*.csv contain the specificity probability.

Row format
cell name, gap junction specifificy probability, presynaptic specificity probability, postsynaptic specificity probability

Files synapse_position_*.csv contain the (weighted) mean synapse positions
Row format
synapse type ('pre','post','gap'), cell1, cell2, weighted mean synapse position along neurite of cell1

If synapse type is 'pre', then cell1 is the presynaptic cell and cell2 is the postsynaptic cell.
If synapse type is 'post', then cell1 is the postsynaptic cell and cell2 is the presynaptic cell.
If synapse type is 'gap', then there is not synaptic polarity. 

synapse_to_adjacency_ratio_*.csv contain the ratio of synaptic to adjacency contact
Row format
synapse type ('pre','post','gap'), cell1, cell2, ratio of # of synaptic sections to # of adjacency sections

If synapse type is 'pre', then cell1 is the presynaptic cell and cell2 is the postsynaptic cell.
If synapse type is 'post', then cell1 is the postsynaptic cell and cell2 is the presynaptic cell.
If synapse type is 'gap', then there is not synaptic polarity.

